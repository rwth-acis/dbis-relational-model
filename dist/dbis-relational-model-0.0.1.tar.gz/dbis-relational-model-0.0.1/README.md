# DBIS Relational Model 

This set of classes is used to define objects of the relational model (as a result of a conversion from an ER-diagram)

## Usage

Todo
